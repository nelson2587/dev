package com.TiendaLooneyTunes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaLooneyTunesApplicationTests {

	@Test
	void contextLoads() {
	}

}
