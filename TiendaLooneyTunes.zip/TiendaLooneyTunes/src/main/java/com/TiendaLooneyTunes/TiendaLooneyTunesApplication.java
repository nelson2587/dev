package com.TiendaLooneyTunes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaLooneyTunesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaLooneyTunesApplication.class, args);
	}

}
