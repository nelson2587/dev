/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prueba_1.service;
import com.prueba_1.service.pruebaService;
import java.util.List;
/**
 *
 * @author Nelson
 */
public class pruebaService {
 public List<prueba_1> getid_examen(boolean activos);
 public Prueba1 getPrueba1(PruebaDao Prueba1);
  public void save(PruebaDao prueba_1);
  public void delete(PruebaDao prueba_1);
}
