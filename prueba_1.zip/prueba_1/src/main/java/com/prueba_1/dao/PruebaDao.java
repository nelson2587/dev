package com.prueba_1.dao;
import com.prueba.domain;
import org.springframework.data.jpa.repository.JpaRepository;
 
public interface PruebaDao extends JpaRepository <PruebaDao,Long> {
}